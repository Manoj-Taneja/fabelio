<?php

class Mandrill_Internal
{
    public function __construct(Mandrill_Mandrill $master)
    {
        $this->master = $master;
    }

}


